from django.apps import AppConfig


class MmappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mmapp'
